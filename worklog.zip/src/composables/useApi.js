// src/composables/useApi.js

// ⚠️ UPDATE URL INI dengan URL deployment GAS terbaru Anda ⚠️
const GAS_URL =
	"https://script.google.com/macros/s/AKfycbz7DnE9E2aKlCt9jSaIaZhY1ZL0Gj4LqhRhONbrYCvZ1OXSydojQD3lC8BBebqsExE9/exec";

// ─── GET Request ───────────────────────────────────────────
async function get(action) {
	try {
		const res = await fetch(`${GAS_URL}?action=${action}`, {
			method: "GET",
			redirect: "follow",
		});

		if (!res.ok) {
			throw new Error(`HTTP error! status: ${res.status}`);
		}

		const data = await res.json();

		if (data.error) {
			throw new Error(data.error);
		}

		return data;
	} catch (err) {
		console.error(`GET ${action} error:`, err);
		throw err;
	}
}

// ─── POST Request (handling file upload) ───────────────────
async function post(payload) {
  try {
    const res = await fetch(GAS_URL, {
      method: "POST",
      // Kita hapus redirect: "follow" karena secara default fetch sudah mengikutinya,
      // dan kita ubah header agar tidak memicu preflight OPTIONS
      headers: {
        "Content-Type": "text/plain;charset=utf-8", 
      },
      body: JSON.stringify(payload),
    });

    // Catatan: Fetch ke GAS akan mengembalikan status 200 setelah redirect manual, 
    // tapi karena kita butuh data JSON, kita pastikan parsing-nya aman.
    const data = await res.json();

    if (data.error) {
      throw new Error(data.error);
    }

    return data;
  } catch (err) {
    console.error("POST error:", err);
    throw err;
  }
}

// ─── Helper: Convert file to base64 ────────────────────────
function fileToBase64(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => {
			const base64 = reader.result.split(",")[1];
			resolve(base64);
		};
		reader.onerror = (error) => reject(error);
		reader.readAsDataURL(file);
	});
}

// ─── API Functions ─────────────────────────────────────────
export function useApi() {
	// Get all logbook entries
	async function getLogbook() {
		return get("getLogbook");
	}

	// Get all assigners
	async function getAssigners() {
		return get("getAssigners");
	}

	// Create logbook without file
	async function createLogbook(data) {
		return post({ action: "createLogbook", data });
	}

	// Update logbook without file
	async function updateLogbook(data) {
		return post({ action: "updateLogbook", data });
	}

	// Delete logbook
	async function deleteLogbook(id) {
		return post({ action: "deleteLogbook", id });
	}

	// Upload file and create logbook (1 request)
	async function uploadFileAndCreate(file, logbookData) {
		try {
			const base64Data = await fileToBase64(file);

			const result = await post({
				action: "uploadAndCreate",
				fileName: file.name,
				mimeType: file.type,
				base64Data: base64Data,
				data: logbookData,
			});

			return result;
		} catch (err) {
			console.error("uploadFileAndCreate error:", err);
			throw err;
		}
	}

	// Upload file and update logbook (1 request)
	async function uploadFileAndUpdate(file, logbookData) {
		try {
			const base64Data = await fileToBase64(file);

			const result = await post({
				action: "uploadAndUpdate",
				fileName: file.name,
				mimeType: file.type,
				base64Data: base64Data,
				data: logbookData,
			});

			return result;
		} catch (err) {
			console.error("uploadFileAndUpdate error:", err);
			throw err;
		}
	}

	return {
		getLogbook,
		getAssigners,
		createLogbook,
		updateLogbook,
		deleteLogbook,
		uploadFileAndCreate,
		uploadFileAndUpdate,
	};
}

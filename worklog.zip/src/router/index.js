import { createRouter, createWebHashHistory } from "vue-router";
import Dashboard from "../views/Dashboard.vue";
import LogbookView from "../views/LogbookView.vue";

const routes = [
  { path: "/", redirect: "/dashboard" },
  { path: "/dashboard", component: Dashboard, name: "dashboard" },
  { path: "/logbook", component: LogbookView, name: "logbook" },
];

export default createRouter({
  history: createWebHashHistory(),
  routes,
});
